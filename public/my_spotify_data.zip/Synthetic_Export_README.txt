Synthetic Spotify Extended Streaming History demo archive.
All records are generated and non-personal.
Generated deterministically with seed: 0x1f2e3d4c